

    <div class="account-selection-container">
        <?php $__currentLoopData = $businessAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="account-card">
            <div class="account-card-header">
                <img src="<?php echo e($account['profile_picture_url']); ?>" alt="Facebook Page Profile" class="profile-image">
            </div>
            <div class="account-card-body">
                <h4>Facebook Page:</h4>
                <p><?php echo e($account['page_name']); ?></p>
                <h4>Professional Instagram account:</h4>
                <a href="https://instagram.com/<?php echo e($account['instagram']['username']); ?>" class="instagram-handle"><?php echo e('@'.$account['instagram']['username']); ?></a>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/resources/views/account_selection.blade.php ENDPATH**/ ?>