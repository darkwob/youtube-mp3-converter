<pre><?php echo e(print_r($pageInfo)); ?></pre>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/resources/views/getPageInfo.blade.php ENDPATH**/ ?>