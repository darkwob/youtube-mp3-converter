<pre><?php echo e(print_r($pages)); ?></pre>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/resources/views/getPages.blade.php ENDPATH**/ ?>