<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instagram Access Token</title>
</head>
<body>

    <h1>Access Token</h1>
    <p><strong>Token:</strong> {{ $token['access_token'] }}</p>
    <p><strong>Token Type:</strong> {{ $token['token_type'] }}</p>

</body>
</html>
