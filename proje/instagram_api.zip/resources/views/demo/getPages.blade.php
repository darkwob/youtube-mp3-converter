<pre>{{print_r($pages)}}</pre>
