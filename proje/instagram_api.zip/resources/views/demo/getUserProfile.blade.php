<pre>{{print_r($userInfo)}} <pre>
